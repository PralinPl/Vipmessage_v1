<?php

namespace VipMessage;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pockemine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("VipMessage Load");
	}
	public function onCommand ( CommandSender $sender , Command $command , $label , array $args ): bool{
		if(strtolower($command->getName('vip'))) {
			if(empty($args)) {
				$sender->sendMessage("§l§8)§7===========§8( (§cVIP§8) )§7===========§8(");
$sender->SendMessage("");
$sender->SendMessage("");
$sender->SendMessage("");
$sender->SendMessage("");
$sender->SendMessage("");
$sender->SendMessage("");
$sender->SendMessage("");->sendMessage("§l§8)§7===========§8( (§cVIP§8) )§7===========§8(");
 return true ;
			}
		}
	}
}
